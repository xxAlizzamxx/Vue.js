import { supabase } from "./supabase.js";
const user = document.getElementById("user");
const password = document.getElementById("pass");
const loginform = document.getElementById("loginform");

loginform.addEventListener("submit", async(event) => {
  event.preventDefault();

  if (user.value.trim() === "")
    return alert("The User field is empty");

  if (password.value.trim() === "")
    return alert("The Password field is empty");

  const { data, error } = await supabase
    .from("usuarios")
    .select("*")
    .eq("username", user.value)
    .eq("password", password.value)
    .single();

  if (error || !data) {
    alert("Usuario o contraseña incorrectos ❌");
    return;
  }

  alert("Login exitoso ✔");
  limpiar();
});

function limpiar() {
  user.value = "";
  password.value = "";
}