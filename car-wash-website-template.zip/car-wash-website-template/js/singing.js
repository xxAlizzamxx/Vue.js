import { supabase } from "./supabase.js";
const user = document.getElementById("user");
const account = document.getElementById("account");
const password = document.getElementById("pass");
const passwordconf = document.getElementById("passconf");
const singinform = document.getElementById("singinform");

singinform.addEventListener("submit", async (event) => {
  event.preventDefault();

  if (user.value.trim() === "")
    return alert("The User field is empty");

  if (account.value.trim() === "")
    return alert("The Account field is empty");

  if (password.value.trim() === "")
    return alert("The Password field is empty");

  if (passwordconf.value.trim() !== password.value.trim())
    return alert("Passwords do not match");

  const { data, error } = await supabase
    .from("usuarios")
    .insert([
      {
        username: user.value,
        account: account.value,
        password: password.value
      }
    ]);

  if (error) {
    alert("Error: " + error.message);
    return;
  }

  alert("Usuario registrado correctamente");
  limpiar2();
});

function limpiar2() {
  user.value = "";
  account.value = "";
  password.value = "";
  passwordconf.value = "";
}