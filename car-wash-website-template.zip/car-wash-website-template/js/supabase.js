import { createClient } from 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js/+esm';

const supabaseUrl = "https://vzhykaolpwvmbdieaynj.supabase.co";
const supabaseKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZ6aHlrYW9scHd2bWJkaWVheW5qIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjQ0NzU0ODAsImV4cCI6MjA4MDA1MTQ4MH0.iRcdn6tRrbl3xJ-KZ_ossLCMks53qDqH7zZqSM-O2LM";

export const supabase = createClient(supabaseUrl, supabaseKey);